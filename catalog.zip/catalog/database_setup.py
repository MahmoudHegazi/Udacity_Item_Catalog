#!/usr/bin/env python3

"""File name: database_setup.py

That's Database Setup file:
    1. run this file to setup your database
    2. run after this lotsofcar.py

More details can be found in the README.md file,
which is included with this project.
"""

__author__ = 'Mahmoud Hegazy'

from sqlalchemy import Column, ForeignKey, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy import create_engine

Base = declarative_base()
# User Table Used To store The Data from Google loginSession


class User(Base):
    __tablename__ = 'user'

    id = Column(Integer, primary_key=True)
    name = Column(String(250), nullable=False)
    email = Column(String(250), nullable=False)
    picture = Column(String(250))

# Car Table Used To store Cars List Information


class Car(Base):

    __tablename__ = 'car'

    id = Column(Integer, primary_key=True)
    name = Column(String(250), nullable=False)
    user_id = Column(Integer, ForeignKey('user.id'))
    user = relationship(User)

    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {

            'name': self.name,
            'id': self.id,
        }

# CarType Table Used To store Cars Post Information(MenuItems)


class CarType(Base):
    __tablename__ = 'car_type'

    name = Column(String(80), nullable=False)
    id = Column(Integer, primary_key=True)
    description = Column(String(250))
    price = Column(String(8))
    car_id = Column(Integer, ForeignKey('car.id'))
    car = relationship(Car)
    user_id = Column(Integer, ForeignKey('user.id'))
    user = relationship(User)

    @property
    def serialize(self):
        """Return object data in easily serializeable format"""
        return {

            'name': self.name,
            'description': self.description,
            'id': self.id,
            'price': self.price,
        }

# Set the .db file path


engine = create_engine('sqlite:///cars.db')

Base.metadata.create_all(engine)
