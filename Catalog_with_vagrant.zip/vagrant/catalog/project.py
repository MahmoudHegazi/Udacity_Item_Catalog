#!/usr/bin/env python3

"""File name: Project.py

It is web server for my the web applaction:
    1. read, update, create, delete from database
    2. using Oauth2 (google +)
    3. having login and logout button
    4. show lastadded Car posts
    
More details can be found in the README.md file,
which is included with this project.
"""

__author__ = 'Mahmoud Hegazy'

from flask import Flask, render_template, request, redirect, jsonify, url_for, flash
from sqlalchemy import create_engine, asc
from sqlalchemy.orm import sessionmaker
from database_setup import Base, Car, CarType, User
from flask import session as login_session
import random
import string
# IMPORTS FOR THIS STEP
from oauth2client.client import flow_from_clientsecrets
from oauth2client.client import FlowExchangeError
import httplib2
import json
from flask import make_response
import requests

app = Flask(__name__)


# google client_secrets  client_id and application_name
CLIENT_ID = json.loads(
    open('client_secret_967937630156-hncennr4gtjel2m45nvt5p61lbso5jvr.apps.googleusercontent.com.json', 'r').read())['web']['client_id']

APPLICATION_NAME = "top cars"

# Connect to Database and create database session
engine = create_engine('sqlite:///cars.db')
Base.metadata.bind = engine

DBSession = sessionmaker(bind=engine)
session = DBSession()

# Create anti-forgery state token

@app.route('/login')
def showLogin():

    state = ''.join(random.choice(string.ascii_uppercase + string.digits) for x in  xrange(32))
    login_session['state'] = state
    # render a login template
    return render_template('login.html',STATE = state)


#Create Gconnet for login page

@app.route('/gconnect', methods = ['POST'])
def gconnect():

    # Validate state token
    if request.args.get('state') != login_session['state']:
        response = make_response(json.dumps('Invalid state parameter.'), 401)
        response.headers['Content-Type'] = 'application/json'
        return response

    # Obtain authorization code
    code = request.data

    try:
        # Upgrade the authorization code into a credentials object
        oauth_flow = flow_from_clientsecrets('client_secret_967937630156-hncennr4gtjel2m45nvt5p61lbso5jvr.apps.googleusercontent.com.json', scope = '')
        oauth_flow.redirect_uri = 'postmessage'
        credentials = oauth_flow.step2_exchange(code)

    except FlowExchangeError:
        response = make_response(
            json.dumps('Failed to upgrade the authorization code.'), 401)

        response.headers['Content-Type'] = 'application/json'
        return response

    # Check that the access token is valid.
    access_token = credentials.access_token

    url = ('https://www.googleapis.com/oauth2/v1/tokeninfo?access_token=%s'
           % access_token)

    h = httplib2.Http()
    result = json.loads(h.request(url, 'GET')[1])
    # If there was an error in the access token info, abort.

    if result.get('error') is not None:
        response = make_response(json.dumps(result.get('error')), 500)
        response.headers['Content-Type'] = 'application/json'
        return response

    # Verify that the access token is used for the intended user.
    gplus_id = credentials.id_token['sub']

    if result['user_id'] != gplus_id:
        response = make_response(
            json.dumps("Token's user ID doesn't match given user ID."), 401)

        response.headers['Content-Type'] = 'application/json'
        return response

    # Verify that the access token is valid for this app.
    if result['issued_to'] != CLIENT_ID:
        response = make_response(
            json.dumps("Token's client ID does not match app's."), 401)

        print "Token's client ID does not match app's."
        response.headers['Content-Type'] = 'application/json'
        return response

    stored_access_token = login_session.get('access_token')
    stored_gplus_id = login_session.get('gplus_id')

    if stored_access_token is not None and gplus_id == stored_gplus_id:
        response = make_response(json.dumps('Current user is already connected.'),200)
        response.headers['Content-Type'] = 'application/json'
        return response

    # Store the access token in the session for later use.
    login_session['access_token'] = credentials.access_token
    login_session['gplus_id'] = gplus_id

    # Get user info
    userinfo_url = "https://www.googleapis.com/oauth2/v1/userinfo"
    params = {'access_token': credentials.access_token, 'alt': 'json'}
    answer = requests.get(userinfo_url, params=params)
    data = answer.json()
    login_session['username'] = data['name']
    login_session['picture'] = data['picture']
    login_session['email'] = data['email']

    #new edit here
    #see if use exists, if it doesn't make a new one
    user_id = getUserID(login_session['email'])

    if not user_id:
        user_id = createUser(login_session)

    login_session['user_id'] = user_id
    output = ''
    output += '<h1>Welcome, '
    output += login_session['username']
    output += '!</h1>'
    output += '<img src="'
    output += login_session['picture']
    output += ' " style = "width: 300px; height: 300px;border-radius: 150px;-webkit-border-radius: 150px;-moz-border-radius: 150px;"> '
    flash("you are now logged in as %s" % login_session['username'])
    print "done!"
    return output


# User Helper Functions
# Create New User Geting Data from google

def createUser(login_session):

    newUser = User(name = login_session['username'], email = login_session['email'], picture = login_session['picture'])
    session.add(newUser)
    session.commit()
    user = session.query(User).filter_by(email = login_session['email']).one()
    return user.id

#Takes User_Id and Return User object

def getUserInfo(user_id):

    user = session.query(User).filter_by(id = user_id).one()
    return user

#Take Email And return UserId

def getUserID(email):

    try:
        user = session.query(User).filter_by(email = email).one()
        return user.id
    except:
        return None

# DISCONNECT - Revoke a current user's token and reset their login_session

@app.route('/gdisconnect')
def gdisconnect():

    access_token = login_session.get('access_token')

    if access_token is None:
        print 'Access Token is None'
        response = make_response(json.dumps('Current user not connected.'), 401)
        response.headers['Content-Type'] = 'application/json'
        return response

    print 'In gdisconnect access token is %s', access_token
    print 'User name is: '
    print login_session['username']

    url = 'https://accounts.google.com/o/oauth2/revoke?token=%s' % login_session['access_token']

    h = httplib2.Http()

    result = h.request(url, 'GET')[0]

    print 'result is '
    print result

    if result['status'] == '200':
        del login_session['access_token']
        del login_session['gplus_id']
        del login_session['username']
        del login_session['email']
        del login_session['picture']
        response = make_response(json.dumps('Successfully disconnected.'), 200)
        response.headers['Content-Type'] = 'application/json'
        flash('Successfully disconnected Bye Bye.')
        return redirect(url_for('showCars'))

    else:
        response = make_response(json.dumps('Failed to revoke token for given user.', 400))
        response.headers['Content-Type'] = 'application/json'
        return response


# JSON APIs to view Car Information
# JSON APIs to view Car with id and it's Menu

@app.route('/car/<int:car_id>/menu/JSON')
def showMenuJSON(car_id):
    items = session.query(CarType).filter_by(car_id=car_id).all()
    return jsonify(CarModel = [i.serialize for i in items])


# JSON APIs to view Car 1 MenuItem

@app.route('/car/<int:car_id>/menu/<int:menu_id>/JSON')
def menuItemJSON(car_id, menu_id):
    Menu_Item = session.query(CarType).filter_by(id = menu_id).one()
    return jsonify(Menu_Item = Menu_Item.serialize)


#Return JSON object for cars id and name

@app.route('/car/JSON')
def carsJSON():
    cars = session.query(Car).all()
    return jsonify(cars = [r.serialize for r in cars])


#Search Helper Function
# this for handling search page in new page and  I added search
#alghrothem to showCars() without new page

@app.route('/search/', methods = ['GET', 'POST'])
def makeSearch():

    if request.method == 'POST':
        myid = request.form['search']
        car = session.query(CarType).filter_by(name = myid).one()
        return render_template('menu.html', car = car)

    else:
        return render_template('search.html')


# Show all Cars

@app.route('/')
@app.route('/car/', methods = ['GET', 'POST'])
def showCars():

    cars = session.query(Car).order_by(asc(Car.name))

    # this for showing The last Added
    # I couldn't make normal Join So I created It easy

    get_lastAdded = session.query(CarType).order_by(CarType.id.desc()).limit(5).all()

    print get_lastAdded
    lastAdded = []
    lastCars = []
    index = 0

    for i in get_lastAdded:
        carName = session.query(Car).filter_by(id = i.car_id).one()

        class myObject:
            model = i.name
            name = carName.name
            myid = carName.id
            link = 'http://localhost:8000/car/' + str(i.car_id) + '/menu/' + str(i.id)

        print(myObject.link)
        lastAdded.append(myObject)

# search function with seacurty features and error handling and AI
# It's good Search It has good logic and handle errors
        if request.method == 'POST':

            # clear lastAdded from any items
            try:
                lastAdded = []

                for i in get_lastAdded:
                    carName = session.query(Car).filter_by(id = i.car_id).one()

                    class myObject:
                        model = i.name
                        name = carName.name
                        myid = carName.id
                        link = 'http://localhost:8000/car/' + str(i.car_id) + '/menu/' + str(i.id)

                    lastAdded.append(myObject)

                search_text = request.form['search']
                getcar = session.query(CarType).filter_by(name = search_text).one()

                if getcar:
                    flash('This Car With Name %s is Still available for purchase' %search_text)
                    return render_template('search.html', getcar = getcar)

            except:
                flash('This Car With Name %s sold or not existed' %search_text)
                print lastAdded
                
                if 'username' not in login_session:
                    return render_template('publiccars.html', cars = cars, last = lastAdded)
                
                else:
                    return render_template('cars.html', cars=cars, last = lastAdded)

    #Return render_template('publicmenu.html', car = car, car_id = car.car_id, menu_id = car.id, tests = tests)
    if 'username' not in login_session:
        return render_template('publiccars.html', cars = cars, last = lastAdded)
    else:
        return render_template('cars.html', cars = cars, last = lastAdded)


# Create a new Car

@app.route('/car/new/', methods = ['GET', 'POST'])
def newCar():

    #Check if login_session didn't store username
    #Tha'ts mean not loged in redirct to login with flash message
    if 'username' not in login_session:
        flash('Please Login In To Add new Car')
        return redirect('/login')

    if request.method == 'POST':
        newCar = Car(name = request.form['name'], user_id = login_session['user_id'])
        session.add(newCar)        
        flash('New Car %s Successfully Created' % newCar.name)
        session.commit()
        return redirect(url_for('showCars'))

    else:
        return render_template('newCar.html')


# To make user made item can edit it
# Add another clumon id DB in Car for creator
# Compare it with session_login['username']

@app.route('/car/<int:car_id>/edit/', methods = ['GET', 'POST'])
def editCar(car_id):

    editedCar = session.query(Car).filter_by(id = car_id).one()

    #check if login_session didn't store username
    if 'username' not in login_session:
        flash('Please Login In To edit Car and you must be the createor ')
        return redirect('/login')

    if editedCar.user_id != login_session['user_id']:
        return "<script>function myFunction() {alert('You are not authorized to edit this restaurant. Please create your own restaurant in order to edit.');}</script><body onload='myFunction()''>"

    if request.method == 'POST':
        if request.form['name']:
            editedCar.name = request.form['name']
            flash('Car Successfully Edited %s' % editedCar.name)
            return redirect(url_for('showCars'))
    else:
        return render_template('editCar.html', car = editedCar)


# Delete a Car

@app.route('/car/<int:car_id>/delete/', methods = ['GET', 'POST'])
def deleteCar(car_id):

    carToDelete = session.query(Car).filter_by(id = car_id).one()

    if 'username' not in login_session:
        flash('Please Login In To Delete Car and you must be the createor ')
        return redirect('/login')

    if carToDelete.user_id != login_session['user_id']:
        return "<script>function myFunction() {alert('You are not authorized to delete this restaurant. Please create your own restaurant in order to delete.');}</script><body onload='myFunction()''>"

    if request.method == 'POST':
        session.delete(carToDelete)

        flash('%s Successfully Deleted' % carToDelete.name)
        session.commit()
        return redirect(url_for('showCars', car_id = car_id))

    else:
        return render_template('deleteCar.html', car = carToDelete)


# Show a Car menu

@app.route('/car/<int:car_id>/')
@app.route('/car/<int:car_id>/menu/')
def showMenu(car_id):
    
    car = session.query(Car).filter_by(id = car_id).one()
    creator = getUserInfo(car.user_id)
    items = session.query(CarType).filter_by(car_id = car_id).all()
    
    if 'username' not in login_session or creator.id != login_session['user_id']:
        return render_template('publicmenu.html', items = items, car = car, creator = creator)
    
    else:
        return render_template('menu.html', items = items, car = car, creator = creator)


#Post or speacifc car Page

@app.route('/car/<int:car_id>/menu/<int:menu_id>' , methods = ['GET', 'POST'])
@app.route('/car/<int:car_id>/menu/<int:menu_id>/page' , methods = ['GET', 'POST'])
def showPost(car_id, menu_id):

    car = session.query(Car).filter_by(id = car_id).one()
    slectedItem = session.query(CarType).filter_by(id = menu_id).one()
    creator = getUserInfo(car.user_id)

    try:
        getUser = login_session['username']
    except:
        pass

    myLink = 'http:localhost:8000/login'

    #Artificial Intelligence Style
    if 'username' not in login_session:
        flash('TopCars: Hello New User signup now for free Vist this Link:')
        flash('%s' % myLink)
        return render_template('publicpost.html', car = car, myitems = slectedItem ,  creator = creator)

    if 'username' not in login_session and creator.id != login_session['user_id']:
        flash('TopCars: This Selling Post Is read Only Create Your Own Post ' )
        return render_template('publicpost.html', car = car, myitems = slectedItem, creator = creator)

    if 'username' in login_session and creator.id == login_session['user_id']:
        flash('TopCars: Hello Mr %s Fell Free To Update or Delete Your Post' % creator.name)
        return render_template('post.html', car = car, myitems = slectedItem, creator = creator)

    else:
        flash('TopCars: Nice To See You Again %s ' % login_session['username'])
        return render_template('publicpost.html', car = car, myitems = slectedItem, creator = creator)


#Create a new menu item

@app.route('/car/<int:car_id>/menu/new/', methods = ['GET', 'POST'])
def newMenuItem(car_id):
    
    if 'username' not in login_session:
        flash('Please Login In To Create new Car Model')
        return redirect('/login')

    car = session.query(Car).filter_by(id = car_id).one()

    if login_session['user_id'] != car.user_id:
        return "<script>function myFunction() {alert('You are not authorized to add menu items to this restaurant. Please create your own restaurant in order to add items.');}</script><body onload='myFunction()''>"

    if request.method == 'POST':
        newItem = CarType(name = request.form['name'], description = request.form['description'], price = request.form['price'],  user_id = car.user_id, car_id = car_id)
        session.add(newItem)
        session.commit()
        flash('New Car Model %s Item Successfully Created' % (newItem.name))
        return redirect(url_for('showMenu', car_id = car_id))

    else:
        return render_template('newmenuitem.html', car_id = car_id)


#Edit a menu Item

@app.route('/car/<int:car_id>/menu/<int:menu_id>/edit', methods = ['GET', 'POST'])
def editMenuItem(car_id, menu_id):
    
    if 'username' not in login_session:
        flash('Please Login In To Edit Car Model and you must be the createor ')
        return redirect('/login')
    
    editedItem = session.query(CarType).filter_by(id = menu_id).one()
    car = session.query(Car).filter_by(id = car_id).one()

    if login_session['user_id'] != car.user_id:
        return "<script>function myFunction() {alert('You are not authorized to edit menu items to this restaurant. Please create your own restaurant in order to edit items.');}</script><body onload='myFunction()''>"

    if request.method == 'POST':
        
        if request.form['name']:
            editedItem.name = request.form['name']

        if request.form['description']:
            editedItem.description = request.form['description']

        if request.form['price']:
            editedItem.price = request.form['price']

        session.add(editedItem)
        session.commit()
        flash('Car Model Successfully Edited')
        return redirect(url_for('showMenu', car_id = car_id))

    else:
        return render_template('editmenuitem.html', car_id = car_id, menu_id = menu_id, item = editedItem)


#Delete a menu item

@app.route('/car/<int:car_id>/menu/<int:menu_id>/delete', methods = ['GET', 'POST'])
def deleteMenuItem(car_id, menu_id):

    if 'username' not in login_session:
        flash('Please Login In To Delete Car Model and you must be the createor ')
        return redirect('/login')

    car = session.query(Car).filter_by(id = car_id).one()    
    itemToDelete = session.query(CarType).filter_by(id = menu_id).one()

    if login_session['user_id'] != car.user_id:
        return "<script>function myFunction() {alert('You are not authorized to delete menu items to this restaurant. Please create your own restaurant in order to delete items.');}</script><body onload='myFunction()''>"
    
    if request.method == 'POST':
        session.delete(itemToDelete)
        session.commit()
        flash('Car Model Successfully Deleted')
        return redirect(url_for('showMenu', car_id = car_id))
    
    else:
        return render_template('deleteMenuItem.html', car = car, item = itemToDelete)
    
if __name__ == '__main__':
    app.secret_key = 'super_secret_key'
    app.debug = True
    app.run(host = '0.0.0.0', port = 8000, threaded = False)
